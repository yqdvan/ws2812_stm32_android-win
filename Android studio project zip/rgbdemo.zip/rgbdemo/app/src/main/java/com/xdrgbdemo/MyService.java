package com.xdrgbdemo;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Environment;
import android.os.Handler;

import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;


public class MyService extends Service {


    private static final int RECORD_REQUEST_CODE = 66;

    private static final int STORAGE_REQUEST_CODE = 666;
    private static final int AUDIO_REQUEST_CODE = 667;
    private static final int REQUEST_MEDIA_PROJECTION = 668;
    private static final int alpha = 2;
    private static  int width = 1080;
    private static  int height = 0;
    int resultCode = 0;
    Intent intentData=null;

    int BUFFER_SIZE = 61;
    byte writeBuffR[] = new byte[BUFFER_SIZE];
    byte writeBuffG[] = new byte[BUFFER_SIZE];
    byte writeBuffB[] = new byte[BUFFER_SIZE];
    byte writeBuffer[] = new byte[]{(byte)0x02,(byte)0xf0,(byte)0xf0,(byte)0xf0,(byte)0xf0,(byte)0xf0,(byte)0xf0,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0xff};
    int SLEEP_TIME = 50;
    int TIME_OUT = 150;
    UsbManager usbManager;
    UsbDevice usbDevice;
    UsbDeviceConnection usbDeviceConnection;
    UsbInterface usbInterface;
    UsbEndpoint usbEndpointRead,usbEndpointWrite;
    HashMap<String, UsbDevice> deviceHashMap;


    static  String TAG = "sss123";


    public VirtualDisplay virtualDisplay ;
    private MediaProjection mediaProjection = null;
    private ImageReader mImageReader = null;
    private MediaProjectionManager mediaProjectionManager;

    public String sdCardDirBase = Environment.getExternalStorageDirectory()+"/aatest";
    public String sdCardDir ="";

    private Image.Plane[] planes;
    private ByteBuffer buffer;
    private int pixelStride;
    private int rowStride;
    private int rowPadding;


    public MyService() {
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopForeground(true);
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onCreate() {
        super.onCreate();

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
        Notification notification = builder.build();
        startForeground(999, notification);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        mediaProjectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);


        resultCode = intent.getIntExtra("resultCode",-1);
        intentData =intent.getParcelableExtra("resultData");
        height = (intent.getIntExtra("Height",0))*width/(intent.getIntExtra("Width",0));
        //width = intent.getIntExtra("Width",0);
        Log.d(TAG, "onStartCommand: height:"+height+" width:"+width);
        if(height!= 0){
            mImageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2);
        }

        mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, intentData);

        createVirtualDisplay();
        savePicture();

        //--------------test rgb-------------//
        writeBuffR[0] = (byte) (0x00);
        writeBuffG[0] = (byte) (0x01);
        writeBuffB[0] = (byte) (0x02);

        for(int i = 1;i<writeBuffG.length;i++){

            writeBuffR[i] = (byte)72;
            writeBuffG[i] = (byte)209;
            writeBuffB[i] = (byte)204;

        }


        usbManager = (UsbManager) getApplicationContext().getSystemService(Context.USB_SERVICE);
        deviceHashMap = usbManager.getDeviceList();

        for (UsbDevice device : deviceHashMap.values()) {
            Log.d(TAG, "VID: " + device.getVendorId() + " PID: " + device.getProductId());

            usbDevice = device;



            if (usbManager.hasPermission(usbDevice)) {
                usbManager.openDevice(usbDevice);
                Log.d(TAG, "onStartCommand: "+usbDevice.getVendorId() + ": has permission");
                usbDeviceConnection = usbManager.openDevice(usbDevice);
                usbInterface = usbDevice.getInterface(0);
                usbDeviceConnection.claimInterface(usbInterface,true);
                usbInterface.getEndpointCount();
                Log.d(TAG, "onStartCommand: "+"endpoint:"+(usbInterface.getEndpointCount()));

                for(int i = 0;i<usbInterface.getEndpointCount();i++){

                    if(usbInterface.getEndpoint(i).getDirection() == UsbConstants.USB_DIR_IN){
                        usbEndpointRead = usbInterface.getEndpoint(i);
                    }else {
                        usbEndpointWrite = usbInterface.getEndpoint(i);
                    }
                }

//                usbEndpointWrite = usbInterface.getEndpoint(0);
//                usbEndpointRead = usbInterface.getEndpoint(1);

            } else {

                //tryGetUsbPermission();
                Log.d(TAG, "onStartCommand: No usb permission !");

            }
        }

        sendRGB();

//        int i = 0;
//        while(true){
//            if(i%2000==0){
//                Log.d(TAG, "while true is running !");
//                Toast.makeText(this,"services is running",Toast.LENGTH_SHORT).show();
//            }
//          i++;
//        }

        return super.onStartCommand(intent, flags, startId);
    }

    private void sendRGB() {
        if(usbEndpointWrite != null){
            Log.d(TAG, "onStartCommand: rgb send!");
            usbDeviceConnection.bulkTransfer(usbEndpointWrite,writeBuffR,BUFFER_SIZE,TIME_OUT);
            try {
                Thread.sleep(SLEEP_TIME);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            usbDeviceConnection.bulkTransfer(usbEndpointWrite,writeBuffG,BUFFER_SIZE,TIME_OUT);
            try {
                Thread.sleep(SLEEP_TIME);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            usbDeviceConnection.bulkTransfer(usbEndpointWrite,writeBuffB,BUFFER_SIZE,TIME_OUT);
            try {
                Thread.sleep(SLEEP_TIME);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void createVirtualDisplay() {
        Log.d(TAG, "createVirtualDisplay: ");
        virtualDisplay = mediaProjection.createVirtualDisplay(
                "screen-mirror",
                width,
                height,
                Resources.getSystem().getDisplayMetrics().densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                mImageReader.getSurface(),
                null,
                null
        );

    }
    private void savePicture(){
        Log.d(TAG, "savePicture: ");


        //获取当前时间并作为时间戳给文件夹命名

        try {
            Thread.sleep(500);

            Image image = mImageReader.acquireLatestImage();

            if (image == null) {
                Log.d(TAG, " " + "image:null");
            } else {
                planes = (image).getPlanes();
                buffer = planes[0].getBuffer();
                pixelStride = planes[0].getPixelStride();
                rowStride = planes[0].getRowStride();
                rowPadding = rowStride - pixelStride * width;


                Bitmap bitmap = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888);
                //Bitmap bitmap = Bitmap.createBitmap(width , height, Bitmap.Config.ARGB_8888);
                bitmap.copyPixelsFromBuffer(buffer);
                bitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height);
                for(int i = 0 ; i<60 ; i++){
                    //Log.d(TAG, "savePicture: RGB value: the pixel "+i+"  is  :"+bitmap.getPixel(i,0));
                    //bitmap.getPixels();
                    int color = bitmap.getPixel(i,2);
                    writeBuffR[60-i]= (byte) (((color)&( 0x00ff0000) >> 16)/alpha);
                    writeBuffG[60-i]= (byte) (((color& 0x0000ff00) >> 8)/alpha);
                    writeBuffB[60-i]= (byte) ((color& 0x000000ff)/alpha);
                }
                sendRGB();

                SimpleDateFormat simpleDateFormat =new SimpleDateFormat("yyyyMMddHHmmssSSS");
                String timeString=simpleDateFormat.format(new Date());

                sdCardDir = sdCardDirBase + "/Services" + timeString + ".jpg";
                //Log.d(TAG, "onImageAvailable: "+sdCardDir);

                saveBitmap(bitmap, sdCardDir);

                bitmap.recycle();
                buffer.clear();
                image.close();
            }

            mImageReader.setOnImageAvailableListener(new ImageAvailableListener() ,null);


            //Thread.sleep(100);


        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }




    /**
     * 保存bitmap到本地
     *
     * @param bitmap Bitmap
     */
    public static void saveBitmap(Bitmap bitmap,String path) {
        String savePath;
        File filePic;
        if (Environment.getExternalStorageState().equals(
                Environment.MEDIA_MOUNTED)) {
            savePath = path;
        } else {
            Log.e(TAG, "saveBitmap failure : sdcard not mounted");
            return;
        }
        try {
            filePic = new File(savePath);
            if (!filePic.exists()) {
                filePic.getParentFile().mkdirs();
                filePic.createNewFile();
            }
            FileOutputStream fos = new FileOutputStream(filePic);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
        } catch (IOException e) {
            Log.e(TAG, "saveBitmap: " + e.getMessage()+"   "+savePath);
            return;
        }
        Log.i(TAG, "saveBitmap success: " + filePic.getAbsolutePath());
    }


    public class ImageAvailableListener implements ImageReader.OnImageAvailableListener {
        private  int IMAGES_PRODUCED = 0;

        @Override
        public void onImageAvailable(ImageReader reader) {
            try (Image image = reader.acquireLatestImage()) {
                if (image != null) {
                    //String name = String.valueOf(System.currentTimeMillis());
                    IMAGES_PRODUCED++;
                    Log.e(TAG, String.valueOf(IMAGES_PRODUCED));

//                    if (IMAGES_PRODUCED%10 == 0){
//                        savePicture();
//
//                    }
                    int flg =0;
                    while (flg<10){
                        Log.d(TAG, "flg : "+flg);
                        savePicture();
                        image.close();
                        flg++;
                    }

                }

            } catch (Exception e) {
                e.printStackTrace();
            }


        }
    }





}
