package com.xdrgbdemo;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.hardware.usb.UsbRequest;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    UsbManager usbManager;
    UsbDevice usbDevice;
    UsbDeviceConnection usbDeviceConnection;
    UsbInterface usbInterface;
    UsbEndpoint usbEndpointRead,usbEndpointWrite;
    HashMap<String, UsbDevice> deviceHashMap;

    private TextView tvInfo;
    private Button btnOther;
    private Button btnRead;
    private Button btnWrite;
    ScrollView scrollView;

    String inf = " ";
    int BUFFER_SIZE = 61;
    int SLEEP_TIME = 50;
    int TIME_OUT = 150;
    int IN_SLEEP_TIME =1000;
    byte writeBuffR[] = new byte[BUFFER_SIZE];
    byte writeBuffB[] = new byte[]{(byte)0x02,(byte)0xf0,(byte)0xf0,(byte)0xf0,(byte)0xf0,(byte)0xf0,(byte)0xf0,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0x06,(byte)0xff};
    byte writeBuffG[] = new byte[BUFFER_SIZE];
    byte readBuff[] = new byte[BUFFER_SIZE];

    //--------------------record ----------//

    private static final int RECORD_REQUEST_CODE = 66;

    private static final int STORAGE_REQUEST_CODE = 666;
    private static final int AUDIO_REQUEST_CODE = 667;

    private static  int width = 0;
    private static  int height = 0;

    static  String TAG = "M123";


    public VirtualDisplay virtualDisplay ;
    private MediaProjection mediaProjection = null;
    private ImageReader mImageReader = null;
    private MediaProjectionManager mediaProjectionManager;

    public String sdCardDir = Environment.getExternalStorageDirectory()+"/123.jpg";
    //----------------record end--------------//

    //@Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        ScreenShotHelper screenShotHelper = new ScreenShotHelper(MainActivity.this, resultCode, data, new ScreenShotHelper.OnScreenShotListener() {
//            @Override
//            public void onFinish(Bitmap bitmap) {
//                mImageView.setImageBitmap(bitmap);
//            }
//        });
//        screenShotHelper.startScreenShot();
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //-------------record----------//
        Display defaultDisplay = getWindowManager().getDefaultDisplay();
        Point point = new Point();
        defaultDisplay.getSize(point);
        width = point.x;
        height = point.y;
        Log.d(TAG, "width = " + width + ",height = " + height);

        mImageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 1);


        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_REQUEST_CODE);
        }
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.RECORD_AUDIO}, AUDIO_REQUEST_CODE);
        }

        //-------------record end---------//
        //--------------permission----------//
        getPermission(MainActivity.this);

        record(MainActivity.this);

        usbManager = (UsbManager) getApplicationContext().getSystemService(Context.USB_SERVICE);
        deviceHashMap = usbManager.getDeviceList();

        tvInfo = findViewById(R.id.tvInfor);
        btnRead = findViewById(R.id.btnRead);
        btnWrite = findViewById(R.id.btnWrite);
        btnOther = findViewById(R.id.btnOther);
        scrollView = findViewById(R.id.sclView);

        showInf(deviceHashMap.size() + " devices ");

        for (UsbDevice device : deviceHashMap.values()) {
            showInf("VID: " + device.getVendorId() + " PID: " + device.getProductId());

            usbDevice = device;



            if (usbManager.hasPermission(usbDevice)) {
                usbManager.openDevice(usbDevice);
                showInf(usbDevice.getVendorId() + ": has permission");
                usbDeviceConnection = usbManager.openDevice(usbDevice);
                usbInterface = usbDevice.getInterface(0);
                usbDeviceConnection.claimInterface(usbInterface,true);
                usbInterface.getEndpointCount();
                showInf("endpoint:"+(usbInterface.getEndpointCount()));

                for(int i = 0;i<usbInterface.getEndpointCount();i++){

                    if(usbInterface.getEndpoint(i).getDirection() == UsbConstants.USB_DIR_IN){
                        usbEndpointRead = usbInterface.getEndpoint(i);
                    }else {
                        usbEndpointWrite = usbInterface.getEndpoint(i);
                    }
                }

//                usbEndpointWrite = usbInterface.getEndpoint(0);
//                usbEndpointRead = usbInterface.getEndpoint(1);

            } else {

                tryGetUsbPermission();

            }
        }




        btnWrite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showInf("send 80 80 80 "+"sdk api:"+Build.VERSION.SDK_INT);

                writeBuffR[0] = (byte) (0x00);
                writeBuffG[0] = (byte) (0x01);
                writeBuffB[0] = (byte) (0x02);

                //Random random = new Random();
                //byte bt = (byte)random.nextInt(256);
                for(int i = 1;i<writeBuffG.length;i++){

                    writeBuffR[i] = (byte)80;
                    writeBuffG[i] = (byte)80;
                    writeBuffB[i] = (byte)80;
                    //showInf("send "+i+ "RGB: "+writeBuffR[i]+" "+writeBuffG[i]+" "+writeBuffB[i]);
                }

                if(usbEndpointWrite != null){
                    showInf("send buffer ok!");
                    usbDeviceConnection.bulkTransfer(usbEndpointWrite,writeBuffR,BUFFER_SIZE,TIME_OUT);
                    try {
                        Thread.sleep(SLEEP_TIME);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    usbDeviceConnection.bulkTransfer(usbEndpointWrite,writeBuffG,BUFFER_SIZE,TIME_OUT);
                    try {
                        Thread.sleep(SLEEP_TIME);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    usbDeviceConnection.bulkTransfer(usbEndpointWrite,writeBuffB,BUFFER_SIZE,TIME_OUT);
                    try {
                        Thread.sleep(SLEEP_TIME);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        btnRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showInf("send 255 255 255  协议："+usbDevice.getDeviceProtocol());
                writeBuffR[0] = (byte) (0x00);
                writeBuffG[0] = (byte) (0x01);
                writeBuffB[0] = (byte) (0x02);

                //Random random = new Random();
                //byte bt = (byte)random.nextInt(256);
                for(int i = 1;i<writeBuffG.length;i++){

                    writeBuffR[i] = (byte)255;
                    writeBuffG[i] = (byte)255;
                    writeBuffB[i] = (byte)255;
                    //showInf("send "+i+ "RGB: "+writeBuffR[i]+" "+writeBuffG[i]+" "+writeBuffB[i]);
                }

                if(usbEndpointWrite != null){
                    showInf("send buffer ok!");
                    usbDeviceConnection.bulkTransfer(usbEndpointWrite,writeBuffR,BUFFER_SIZE,TIME_OUT);
                    try {
                        Thread.sleep(SLEEP_TIME);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    usbDeviceConnection.bulkTransfer(usbEndpointWrite,writeBuffG,BUFFER_SIZE,TIME_OUT);
                    try {
                        Thread.sleep(SLEEP_TIME);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    usbDeviceConnection.bulkTransfer(usbEndpointWrite,writeBuffB,BUFFER_SIZE,TIME_OUT);
                    try {
                        Thread.sleep(SLEEP_TIME);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

//                if(usbEndpointRead != null){
//                    showInf("receive buffer ok!");
//                    usbDeviceConnection.bulkTransfer(usbEndpointRead,readBuff,BUFFER_SIZE,3000);
//                }
//
//                for(int i = 0;i<10;i++){
//                    showInf("receive :"+readBuff[4*i]);
//                }
            }
        });

        btnOther.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(MainActivity.this, "666", Toast.LENGTH_SHORT).show();


                mediaProjectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                startActivityForResult(mediaProjectionManager.createScreenCaptureIntent(), RECORD_REQUEST_CODE);


//                Thread thread = new Thread() {
//
//                    @Override
//                    public void run() {
//                        super.run();
//                        for (int flg = 0; flg < 10; flg++) {
//
//                            if (flg / 2 == 0) {
//                                writeBuffR[0] = (byte) (0x00);
//                                writeBuffG[0] = (byte) (0x01);
//                                writeBuffB[0] = (byte) (0x02);
//
//
//                                for (int i = 1; i < writeBuffG.length; i++) {
//
//                                    writeBuffR[i] = (byte) 80;
//                                    writeBuffG[i] = (byte) 80;
//                                    writeBuffB[i] = (byte) 80;
//
//                                }
//
//                                if (usbEndpointWrite != null) {
//
//                                    usbDeviceConnection.bulkTransfer(usbEndpointWrite, writeBuffR, BUFFER_SIZE, TIME_OUT);
//                                    try {
//                                        Thread.sleep(SLEEP_TIME);
//                                    } catch (InterruptedException e) {
//                                        e.printStackTrace();
//                                    }
//                                    usbDeviceConnection.bulkTransfer(usbEndpointWrite, writeBuffG, BUFFER_SIZE, TIME_OUT);
//                                    try {
//                                        Thread.sleep(SLEEP_TIME);
//                                    } catch (InterruptedException e) {
//                                        e.printStackTrace();
//                                    }
//                                    usbDeviceConnection.bulkTransfer(usbEndpointWrite, writeBuffB, BUFFER_SIZE, TIME_OUT);
//                                    try {
//                                        Thread.sleep(SLEEP_TIME);
//                                    } catch (InterruptedException e) {
//                                        e.printStackTrace();
//                                    }
//                                }
//                                try {
//                                    Thread.sleep(IN_SLEEP_TIME);
//                                } catch (InterruptedException e) {
//                                    e.printStackTrace();
//                                }
//
//                            } else {
//
//                                writeBuffR[0] = (byte) (0x00);
//                                writeBuffG[0] = (byte) (0x01);
//                                writeBuffB[0] = (byte) (0x02);
//
//
//
//                                for (int i = 1; i < writeBuffG.length; i++) {
//
//                                    writeBuffR[i] = (byte) 255;
//                                    writeBuffG[i] = (byte) 255;
//                                    writeBuffB[i] = (byte) 255;
//
//                                }
//
//                                if (usbEndpointWrite != null) {
//
//                                    usbDeviceConnection.bulkTransfer(usbEndpointWrite, writeBuffR, BUFFER_SIZE, TIME_OUT);
//                                    try {
//                                        Thread.sleep(SLEEP_TIME);
//                                    } catch (InterruptedException e) {
//                                        e.printStackTrace();
//                                    }
//                                    usbDeviceConnection.bulkTransfer(usbEndpointWrite, writeBuffG, BUFFER_SIZE, TIME_OUT);
//                                    try {
//                                        Thread.sleep(SLEEP_TIME);
//                                    } catch (InterruptedException e) {
//                                        e.printStackTrace();
//                                    }
//                                    usbDeviceConnection.bulkTransfer(usbEndpointWrite, writeBuffB, BUFFER_SIZE, TIME_OUT);
//                                    try {
//                                        Thread.sleep(SLEEP_TIME);
//                                    } catch (InterruptedException e) {
//                                        e.printStackTrace();
//                                    }
//                                }
//                                try {
//                                    Thread.sleep(IN_SLEEP_TIME);
//                                } catch (InterruptedException e) {
//                                    e.printStackTrace();
//                                }
//                            }
//
//                        }
//                    }
//                };
//                thread.start();
//                showInf("please wait! thread !");
            }
        });

    }

    private void record(AppCompatActivity activity) {
//        MediaProjectionManager mediaProjectionManager = (MediaProjectionManager) activity.
//                getSystemService(Context.MEDIA_PROJECTION_SERVICE);
//        if (mediaProjectionManager != null){
//            Intent intent = mediaProjectionManager.createScreenCaptureIntent();
//            PackageManager packageManager = activity.getPackageManager();
//            if (packageManager.resolveActivity(intent,PackageManager.MATCH_DEFAULT_ONLY) != null){
//                //存在录屏授权的Activity
//                activity.startActivityForResult(intent,requestCode);
//            }else {
//                Toast.makeText(activity,R.string.can_not_record_tip,Toast.LENGTH_SHORT).show();
//            }
//        }
    }


    void showInf(String string){
        inf += string+"\n";
        tvInfo.setText(inf);
        scrollView.fullScroll(ScrollView.FOCUS_DOWN);
    }

    void getPermission(AppCompatActivity activity){
//        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
//                != PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_REQUEST_CODE);
//        }
//        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO)
//                != PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.RECORD_AUDIO}, AUDIO_REQUEST_CODE);
//        }

        //if (Build.VERSION.SDK_INT >= 23) {
        if (true) {

            //---------------------usb--------------//
            tryGetUsbPermission();

            //----------------audio-------------//
            int checkPermission =
                    ContextCompat.checkSelfPermission(activity, Manifest.permission.RECORD_AUDIO)
                            + ContextCompat.checkSelfPermission(activity, Manifest.permission.READ_PHONE_STATE)
                            + ContextCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                            + ContextCompat.checkSelfPermission(activity, Manifest.permission.READ_EXTERNAL_STORAGE);
            if (checkPermission != PackageManager.PERMISSION_GRANTED) {
                //动态申请
                ActivityCompat.requestPermissions(activity, new String[]{
                        Manifest.permission.RECORD_AUDIO,
                        Manifest.permission.READ_PHONE_STATE,
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE}, 123);
                return;
            } else {
                return;
            }
        }
        return;
    }

    UsbManager mUsbManager;
    private static final String ACTION_USB_PERMISSION = "com.android.example.USB_PERMISSION";

    private void tryGetUsbPermission(){
        mUsbManager = (UsbManager) getSystemService(Context.USB_SERVICE);

        IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
        registerReceiver(mUsbPermissionActionReceiver, filter);

        PendingIntent mPermissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(ACTION_USB_PERMISSION), 0);

        //here do emulation to ask all connected usb device for permission
        for (final UsbDevice usbDevice : mUsbManager.getDeviceList().values()) {
            //add some conditional check if necessary
            //if(isWeCaredUsbDevice(usbDevice)){
            if(mUsbManager.hasPermission(usbDevice)){
                //if has already got permission, just goto connect it
                //that means: user has choose yes for your previously popup window asking for grant perssion for this usb device
                //and also choose option: not ask again
                afterGetUsbPermission(usbDevice);
            }else{
                //this line will let android popup window, ask user whether to allow this app to have permission to operate this usb device
                mUsbManager.requestPermission(usbDevice, mPermissionIntent);
            }
            //}
        }
    }


    private void afterGetUsbPermission(UsbDevice usbDevice){
        //call method to set up device communication
        //Toast.makeText(this, String.valueOf("Got permission for usb device: " + usbDevice), Toast.LENGTH_LONG).show();
        //Toast.makeText(this, String.valueOf("Found USB device: VID=" + usbDevice.getVendorId() + " PID=" + usbDevice.getProductId()), Toast.LENGTH_LONG).show();

        doYourOpenUsbDevice(usbDevice);
    }

    private void doYourOpenUsbDevice(UsbDevice usbDevice){
        //now follow line will NOT show: User has not given permission to device UsbDevice
        UsbDeviceConnection connection = mUsbManager.openDevice(usbDevice);
        //add your operation code here
    }

    private final BroadcastReceiver mUsbPermissionActionReceiver;

    {
        mUsbPermissionActionReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (ACTION_USB_PERMISSION.equals(action)) {
                    synchronized (this) {
                        UsbDevice usbDevice = (UsbDevice) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                        if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                            //user choose YES for your previously popup window asking for grant perssion for this usb device
                            if (null != usbDevice) {
                                afterGetUsbPermission(usbDevice);
                            }
                        } else {
                            //user choose NO for your previously popup window asking for grant perssion for this usb device
                            Toast.makeText(context, String.valueOf("Permission denied for device" + usbDevice), Toast.LENGTH_LONG).show();
                        }
                    }
                }
            }
        };
    }


    //------------record---------------//
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        Toast.makeText(MainActivity.this, "on result", Toast.LENGTH_SHORT).show();
        Log.d(TAG, "onActivityResult: ");
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RECORD_REQUEST_CODE && resultCode == RESULT_OK) {
            //-------------start services ---------//
            //获得录屏权限，启动Service进行录制
            Intent intent=new Intent(MainActivity.this,MyService.class);
            intent.putExtra("resultCode",resultCode);
            intent.putExtra("resultData",data);
            intent.putExtra("Width",width);
            intent.putExtra("Height",height);

            startService(intent);
            Toast.makeText(this,"录屏开始",Toast.LENGTH_SHORT).show();
            Log.d(TAG, "onActivityResult: start Services");

            //mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, data);
        }
        //createVirtualDisplay();
        //savePicture();
    }


    private void createVirtualDisplay() {
        Log.d(TAG, "createVirtualDisplay: ");
        virtualDisplay = mediaProjection.createVirtualDisplay(
                "screen-mirror",
                width,
                height,
                Resources.getSystem().getDisplayMetrics().densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                mImageReader.getSurface(),
                null,
                null
        );

    }
    private void savePicture(){
        Log.d(TAG, "savePicture: ");

        try {
            Thread.sleep(2000);
            Image image = mImageReader.acquireLatestImage();
            int width = image.getWidth();
            int height = image.getHeight();
            final Image.Plane[] planes = image.getPlanes();
            final ByteBuffer buffer = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = planes[0].getRowStride();
            int rowPadding = rowStride - pixelStride * width;
            Bitmap bitmap = Bitmap.createBitmap(width+rowPadding/pixelStride, height, Bitmap.Config.ARGB_8888);
            bitmap.copyPixelsFromBuffer(buffer);
            bitmap = Bitmap.createBitmap(bitmap, 0, 0,width, height);
            saveBitmap(bitmap,sdCardDir);
            image.close();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    /**
     * 保存bitmap到本地
     *
     * @param bitmap Bitmap
     */
    public static void saveBitmap(Bitmap bitmap,String path) {
        String savePath;
        File filePic;
        if (Environment.getExternalStorageState().equals(
                Environment.MEDIA_MOUNTED)) {
            savePath = path;
        } else {
            Log.e(TAG, "saveBitmap failure : sdcard not mounted");
            return;
        }
        try {
            filePic = new File(savePath);
            if (!filePic.exists()) {
                filePic.getParentFile().mkdirs();
                filePic.createNewFile();
            }
            FileOutputStream fos = new FileOutputStream(filePic);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();
        } catch (IOException e) {
            Log.e(TAG, "saveBitmap: " + e.getMessage());
            return;
        }
        Log.i(TAG, "saveBitmap success: " + filePic.getAbsolutePath());
    }



}
